package com.meem.memeber;

public enum Grade {
    BASIC,
    VIP

}
